
// Header start
var navShow=document.getElementById('nav-show');
var navIcon=document.getElementById('nav-icon');
var faBars=document.querySelector('.fa-bars');
var times=document.querySelector('.fa-times');
faBars.addEventListener('click',function(){
    navShow.classList.add('active');
    faBars.style.display="none";
    times.style.display="block";
})
times.addEventListener('click',function(){
    navShow.classList.remove('active');
    faBars.style.display="block";
    times.style.display="none";
})

window.addEventListener('scroll',function(){
    var nav=this.document.querySelector('.sticky-header');
    nav.classList.toggle('sticky',this.window.scrollY>73);
})


// Scroll Button
var scrollBTN=document.getElementById('scrollBTN');
window.onscroll=function(){
    if(document.documentElement.scrollTop>200){
        scrollBTN.style.display="block";
    }else{
        scrollBTN.style.display="none";
    }
}
scrollBTN.addEventListener('click',()=>{
    window.scrollTo(0,0);
    document.documentElement.scrollTop=0;
});